#ifndef SORTER_H
#define SORTER_H
class Sorter
{
    private:

    public:
    int binarySort(int [], int);
    void insertionSort(int [], int);
    int searchNums(int [], int , int, int);
    void displayArray(int [], int);
};
#endif